import { registerWidget } from "@11labs/convai-widget-core";

registerWidget();
