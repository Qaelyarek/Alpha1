import Style from "./styles/Style";

// TODO: Implement the actual widget.
export function ConvAIWidget() {
  return (
    <>
      <Style />
      <p>Hello from ConvAI Widget!</p>
    </>
  );
}
