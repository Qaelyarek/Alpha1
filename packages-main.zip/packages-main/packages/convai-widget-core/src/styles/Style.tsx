import styleSource from "./index.css?inline";

export default function Style() {
  return <style>{styleSource}</style>;
}
